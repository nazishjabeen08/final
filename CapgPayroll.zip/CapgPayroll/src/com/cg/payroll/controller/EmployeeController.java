package com.cg.payroll.controller;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Employee;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.EmployeeDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;

@Controller
public class EmployeeController {
	
	@Autowired
	PayrollServices service;
	
	
	//adding a employee
	@RequestMapping(value="add" , method=RequestMethod.GET)
	public String addData(@ModelAttribute("my") Employee emp)
	{
		return "first";
		
	}
	
	@RequestMapping(value="putData", method=RequestMethod.POST)
	public ModelAndView dataAdd(@ModelAttribute("my") Employee emp) throws PayrollServicesDownException, SQLException, EmployeeDetailsNotFoundException
	{
		
		int empId = service.acceptEmployeeDetails(emp);
		return new ModelAndView("added","empId",empId);
		
	}
	
	// retrieving all employees
	@RequestMapping(value="showAll")
	public ModelAndView showMobiles(Model model) throws PayrollServicesDownException, SQLException
	{	
		List<Employee> allEmployees	= service.getAllEmployeeDetails();
		System.out.println(allEmployees);
		model.addAllAttributes(allEmployees);
		return new ModelAndView("list","empList",allEmployees);
	}
	
	
	
	//searching trainee
	
	@RequestMapping(value="search",method=RequestMethod.GET)
	public String searchData(@ModelAttribute ("data") Employee mSearch)
	{
		return "employeeSearch";
	}
	
	@RequestMapping(value="searchEmployee", method=RequestMethod.POST)
	public ModelAndView searchEmployee(@ModelAttribute("mysearch") Employee emp, Model model) throws EmployeeDetailsNotFoundException, PayrollServicesDownException, SQLException
	{
		int empId = emp.getEmpId();
		Employee data = service.getEmployeeDetails(empId);
		
		BankDetails bankDetail = data.getBankDetails();
		model.addAttribute("bankDetail", bankDetail);
		
		Salary sal = data.getSalary();
		model.addAttribute("sal", sal);
		return new ModelAndView("searchResult", "employee", data);
	
	}
	
		
	//directed to delete
	@RequestMapping(value="delete", method=RequestMethod.GET)
	public String traineeRemove(@ModelAttribute("mySearch") Employee emp)
	{
		return "removeEmployee";
		
	}
	
	//delete
	@RequestMapping(value="deleteEmployee", method=RequestMethod.POST)
	public ModelAndView removeData(@ModelAttribute("mySearch") Employee emp) throws SQLException
	{
		int empId = emp.getEmpId();
		service.removeEmployee(empId);
		return new ModelAndView("removeSucess","employee",empId);
		
	}

	// directed to update jsp
	@RequestMapping(value="update", method=RequestMethod.GET)
	public String updateEmployee(@ModelAttribute("mysearch") Employee emp)
	{
		return "updateEmployee";
		
		
	}
	
	@RequestMapping(value="getEmployeeDetail", method=RequestMethod.POST)
	public ModelAndView getDetail(@ModelAttribute("mysearch") Employee emp, Model model) throws EmployeeDetailsNotFoundException, PayrollServicesDownException, SQLException
	{
		int empId = emp.getEmpId();
		Employee data = service.getEmployeeDetails(empId);
		
		BankDetails bankDetail = data.getBankDetails();
		model.addAttribute("bankDetail", bankDetail);
		
		Salary sal = data.getSalary();
		model.addAttribute("sal", sal);
		return new ModelAndView("show", "employee", data);
	
	}
	//update
	@RequestMapping(value ="updatedata" , method = RequestMethod.POST)
	public ModelAndView updateData(@ModelAttribute("mysearch")Employee emp) throws SQLException
	{
		boolean flag = service.updateEmployee(emp);
		if(flag)
		{
			return new ModelAndView("updateSuccess","empId",emp.getEmpId());
		}
		else
			return new ModelAndView("index");
		
	}
	
	//payroll
		@RequestMapping(value ="payroll" , method = RequestMethod.POST)
		public String findPayroll(@ModelAttribute("mysearch")Employee emp) throws SQLException
		{
			return "searchPayroll";
			
		}
		
		@RequestMapping(value ="getPayrollDetail" , method = RequestMethod.POST)
		public ModelAndView showPayrollData(@ModelAttribute("mysearch")Employee emp) throws SQLException
		{
			int empId = emp.getEmpId();
			Employee prDetail = service.getPayrollDetail(empId);
			return null;
		}
	
}
