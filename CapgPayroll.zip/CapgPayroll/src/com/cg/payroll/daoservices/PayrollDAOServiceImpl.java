package com.cg.payroll.daoservices;

import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.payroll.beans.Employee;

@Transactional
@Repository("dao")
public class PayrollDAOServiceImpl implements PayrollDAOServices
{
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public int insertEmployee(Employee employee) throws SQLException {
		entityManager.persist(employee);
		entityManager.flush();
		return employee.getEmpId();
	}

	@Override
	public boolean updateEmployee(Employee employee) throws SQLException {
		
		entityManager.merge(employee);
		
		return  true;
	}
	@Override
	public void deleteEmployee(int employeeId) throws SQLException {
		
		Employee deleteEmp = entityManager.find(Employee.class, employeeId);
		entityManager.remove(deleteEmp);
		entityManager.flush();
		
		System.out.println("Successfully Removed");

	}

	@Override
	public Employee getEmployee(int employeeId) throws SQLException
	{
		Employee EmpDetail = entityManager.find(Employee.class, employeeId);
		
		return EmpDetail;
	}

	@Override
	public List<Employee> getAllEmployees() throws SQLException {
		Query queryOne = entityManager.createQuery("SELECT e From Employee e");
		List<Employee> allEmployees = queryOne.getResultList();
		System.out.println(allEmployees);
		return allEmployees;
	}

	@Override
	public Employee getPayrollDetail(int empId) {
		// TODO Auto-generated method stub
		return null;
	}

}
