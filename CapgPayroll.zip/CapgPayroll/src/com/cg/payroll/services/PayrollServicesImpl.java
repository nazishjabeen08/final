package com.cg.payroll.services;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.beans.Employee;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.EmployeeDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
@Service("service")
public class PayrollServicesImpl implements PayrollServices {

	@Autowired
	PayrollDAOServices dao;
	
	@Override
	public int acceptEmployeeDetails(Employee employee)throws PayrollServicesDownException, SQLException {
		
		calculateSalary(employee);
		return dao.insertEmployee(employee);
	}

	
	@Override
	public Employee getEmployeeDetails(int employeeid)throws EmployeeDetailsNotFoundException,PayrollServicesDownException, SQLException
	{
		return dao.getEmployee(employeeid);
	}

	@Override
	public List<Employee> getAllEmployeeDetails()
			throws PayrollServicesDownException, SQLException {
		return dao.getAllEmployees();
	}

	@Override
	public void removeEmployee(int empId) throws SQLException {
		dao.deleteEmployee(empId);
		
	}


	@Override
	public boolean updateEmployee(Employee employee) throws SQLException {
		
		return dao.updateEmployee(employee);
	}


	@Override
	public Employee getPayrollDetail(int empId) {
	
		return dao.getPayrollDetail(empId);
	}
	
	public void calculateSalary(Employee employee){
		Salary sal = employee.getSalary();
		sal.setHra(0.4*sal.getBasicSalary());
		sal.setTa(0.2*sal.getBasicSalary());
		sal.setDa(0.25 * sal.getBasicSalary());
		sal.setCompanyPf(3000);
		sal.setEmployeePf(3000);
		sal.setGrossSalary(sal.getBasicSalary()+sal.getHra()+sal.getTa()+sal.getDa()+sal.getCompanyPf()+sal.getEmployeePf());
		
		double pTax = 0.0;
		
		if(sal.getGrossSalary() <= 250000){
			pTax = 0.0;
		}
		
		else if(sal.getGrossSalary() > 250000 && sal.getGrossSalary() <= 500000){
			pTax = 0.05*(sal.getGrossSalary() - 250000 - calcInvestment(employee));
		}
		
		else if(sal.getGrossSalary() > 500000 && sal.getGrossSalary() <= 1000000){
			double pt1 = 0.20*(sal.getGrossSalary() - 500000);
			double pt2 = 0.05*(250000 - calcInvestment(employee));
			pTax = pt1 + pt2;			
		}
		
		else{
			double pt1 = 0.30*(sal.getGrossSalary()-1000000);
			double pt2 = 0.20*(500000);
			double pt3 = 0.05*(250000 - calcInvestment(employee));
			pTax = pt1 + pt2 + pt3;			
		}
		
		sal.setMonthlyTax(pTax/12);
		sal.setNetSalary(sal.getGrossSalary() - sal.getMonthlyTax() - sal.getCompanyPf() - sal.getEmployeePf());
	}
	
	public int calcInvestment(Employee employee){
		if(employee.getYearlyInvestment() <= 150000)
			return employee.getYearlyInvestment();
		else
			return 150000;		
	}

}
